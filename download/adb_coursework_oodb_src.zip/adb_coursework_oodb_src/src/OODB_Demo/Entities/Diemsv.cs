﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OODBDemo.Entities
{
    public class Diemsv
    {
        public string Masv { get; set; }
        public string Mamh { get; set; }
        public double Diem { get; set; }
        public int Lanthu { get; set; }
        public string Ghichu { get; set; }
        public string Hocki { get; set; }
    }

}
