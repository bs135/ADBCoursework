﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OODBDemo
{
    public class NguoiI
    {
        public string Ma { get; set; }
        public string Hoten { get; set; }
        public string Ngaysinh { get; set; }
        public string Cmnd { get; set; }
        public string Gioitinh { get; set; }
        public string Diachi { get; set; }
        public string Dienthoai { get; set; }
    }
}
