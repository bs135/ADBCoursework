﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OODBDemo.Entities
{
    public class Monhoc
    {
        public string Mamh { get; set; }
        public string Tenmh { get; set; }
        public int Sochi { get; set; }
    }
}
