﻿namespace OODBDemo
{
    partial class FormPhanQuyen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.pass = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.listug = new System.Windows.Forms.ComboBox();
            this.taouser = new System.Windows.Forms.Button();
            this.xoausernhom = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.tenuser = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.addusernhom = new System.Windows.Forms.Button();
            this.tgroup = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.listuser = new System.Windows.Forms.ComboBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tim = new System.Windows.Forms.Button();
            this.timuserv = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.timgroup = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tengroup = new System.Windows.Forms.TextBox();
            this.Taogroup = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.huyquyeng = new System.Windows.Forms.Button();
            this.csua = new System.Windows.Forms.CheckBox();
            this.cthem = new System.Windows.Forms.CheckBox();
            this.cxoa = new System.Windows.Forms.CheckBox();
            this.cxem = new System.Windows.Forms.CheckBox();
            this.cgroup = new System.Windows.Forms.ComboBox();
            this.themquyeng = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.gthem = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(352, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Phân quyền cho người dùng";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(12, 40);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.groupBox4);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.groupBox2);
            this.splitContainer1.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer1.Size = new System.Drawing.Size(893, 474);
            this.splitContainer1.SplitterDistance = 445;
            this.splitContainer1.TabIndex = 5;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.pass);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.listug);
            this.groupBox4.Controls.Add(this.taouser);
            this.groupBox4.Controls.Add(this.xoausernhom);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.tenuser);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.addusernhom);
            this.groupBox4.Controls.Add(this.tgroup);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(4, 236);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(427, 231);
            this.groupBox4.TabIndex = 30;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Tạo user và thêm user vào group";
            // 
            // pass
            // 
            this.pass.Location = new System.Drawing.Point(82, 78);
            this.pass.Name = "pass";
            this.pass.Size = new System.Drawing.Size(121, 21);
            this.pass.TabIndex = 36;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 83);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 15);
            this.label8.TabIndex = 35;
            this.label8.Text = "PassWord";
            // 
            // listug
            // 
            this.listug.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listug.FormattingEnabled = true;
            this.listug.Location = new System.Drawing.Point(82, 160);
            this.listug.Name = "listug";
            this.listug.Size = new System.Drawing.Size(121, 23);
            this.listug.TabIndex = 25;
            // 
            // taouser
            // 
            this.taouser.Location = new System.Drawing.Point(217, 50);
            this.taouser.Name = "taouser";
            this.taouser.Size = new System.Drawing.Size(93, 23);
            this.taouser.TabIndex = 34;
            this.taouser.Text = "Tạo User";
            this.taouser.UseVisualStyleBackColor = true;
            this.taouser.Click += new System.EventHandler(this.button2_Click);
            // 
            // xoausernhom
            // 
            this.xoausernhom.Location = new System.Drawing.Point(217, 187);
            this.xoausernhom.Name = "xoausernhom";
            this.xoausernhom.Size = new System.Drawing.Size(133, 23);
            this.xoausernhom.TabIndex = 24;
            this.xoausernhom.Text = "Xóa khỏi nhóm";
            this.xoausernhom.UseVisualStyleBackColor = true;
            this.xoausernhom.Click += new System.EventHandler(this.xoausernhom_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(79, 27);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 15);
            this.label15.TabIndex = 23;
            this.label15.Text = "Tạo User";
            // 
            // tenuser
            // 
            this.tenuser.Location = new System.Drawing.Point(82, 49);
            this.tenuser.Name = "tenuser";
            this.tenuser.Size = new System.Drawing.Size(121, 21);
            this.tenuser.TabIndex = 19;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(8, 52);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(52, 15);
            this.label17.TabIndex = 18;
            this.label17.Text = "Tên User";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(79, 136);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(109, 15);
            this.label14.TabIndex = 17;
            this.label14.Text = "Thêm user vào group";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(-1, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 15);
            this.label3.TabIndex = 16;
            this.label3.Text = "Tên Group";
            // 
            // addusernhom
            // 
            this.addusernhom.Location = new System.Drawing.Point(217, 159);
            this.addusernhom.Name = "addusernhom";
            this.addusernhom.Size = new System.Drawing.Size(133, 23);
            this.addusernhom.TabIndex = 14;
            this.addusernhom.Text = "Thêm vào nhóm";
            this.addusernhom.UseVisualStyleBackColor = true;
            this.addusernhom.Click += new System.EventHandler(this.addusernhom_Click);
            // 
            // tgroup
            // 
            this.tgroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tgroup.FormattingEnabled = true;
            this.tgroup.Location = new System.Drawing.Point(82, 188);
            this.tgroup.Name = "tgroup";
            this.tgroup.Size = new System.Drawing.Size(121, 23);
            this.tgroup.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 157);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 15);
            this.label13.TabIndex = 11;
            this.label13.Text = "Tên user";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.listuser);
            this.groupBox3.Controls.Add(this.dataGridView3);
            this.groupBox3.Controls.Add(this.tim);
            this.groupBox3.Controls.Add(this.timuserv);
            this.groupBox3.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(4, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(427, 214);
            this.groupBox3.TabIndex = 29;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tìm User";
            // 
            // listuser
            // 
            this.listuser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listuser.FormattingEnabled = true;
            this.listuser.Location = new System.Drawing.Point(82, 32);
            this.listuser.Name = "listuser";
            this.listuser.Size = new System.Drawing.Size(121, 23);
            this.listuser.TabIndex = 17;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(9, 82);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(412, 117);
            this.dataGridView3.TabIndex = 15;
            // 
            // tim
            // 
            this.tim.Location = new System.Drawing.Point(217, 33);
            this.tim.Name = "tim";
            this.tim.Size = new System.Drawing.Size(75, 23);
            this.tim.TabIndex = 14;
            this.tim.Text = "Tìm";
            this.tim.UseVisualStyleBackColor = true;
            this.tim.Click += new System.EventHandler(this.tim_Click);
            // 
            // timuserv
            // 
            this.timuserv.AutoSize = true;
            this.timuserv.Location = new System.Drawing.Point(30, 32);
            this.timuserv.Name = "timuserv";
            this.timuserv.Size = new System.Drawing.Size(30, 15);
            this.timuserv.TabIndex = 11;
            this.timuserv.Text = "User";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.timgroup);
            this.groupBox2.Controls.Add(this.dataGridView1);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(429, 214);
            this.groupBox2.TabIndex = 30;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tìm Group";
            // 
            // timgroup
            // 
            this.timgroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.timgroup.FormattingEnabled = true;
            this.timgroup.Location = new System.Drawing.Point(86, 32);
            this.timgroup.Name = "timgroup";
            this.timgroup.Size = new System.Drawing.Size(121, 23);
            this.timgroup.TabIndex = 17;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.Column1,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dataGridView1.Location = new System.Drawing.Point(9, 82);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(399, 117);
            this.dataGridView1.TabIndex = 15;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "group";
            this.Column2.HeaderText = "Group";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "doituong";
            this.Column1.HeaderText = "Đối tượng";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "add";
            this.Column3.HeaderText = "Thêm";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "del";
            this.Column4.HeaderText = "Xóa";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "up";
            this.Column5.HeaderText = "Sửa";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "view";
            this.Column6.HeaderText = "Xem";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(221, 32);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Tìm";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 15);
            this.label2.TabIndex = 11;
            this.label2.Text = "Group";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tengroup);
            this.groupBox1.Controls.Add(this.Taogroup);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.huyquyeng);
            this.groupBox1.Controls.Add(this.csua);
            this.groupBox1.Controls.Add(this.cthem);
            this.groupBox1.Controls.Add(this.cxoa);
            this.groupBox1.Controls.Add(this.cxem);
            this.groupBox1.Controls.Add(this.cgroup);
            this.groupBox1.Controls.Add(this.themquyeng);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.gthem);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 236);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(429, 235);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tạo Group Thêm Hoặc Hủy Quyền Group";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(83, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 15);
            this.label9.TabIndex = 36;
            this.label9.Text = "Gán quyền";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(83, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 15);
            this.label6.TabIndex = 35;
            this.label6.Text = "Tạo Group";
            // 
            // tengroup
            // 
            this.tengroup.Location = new System.Drawing.Point(84, 47);
            this.tengroup.Name = "tengroup";
            this.tengroup.Size = new System.Drawing.Size(121, 21);
            this.tengroup.TabIndex = 33;
            // 
            // Taogroup
            // 
            this.Taogroup.Location = new System.Drawing.Point(220, 47);
            this.Taogroup.Name = "Taogroup";
            this.Taogroup.Size = new System.Drawing.Size(93, 23);
            this.Taogroup.TabIndex = 21;
            this.Taogroup.Text = "Tạo Group";
            this.Taogroup.UseVisualStyleBackColor = true;
            this.Taogroup.Click += new System.EventHandler(this.Taogroup_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 15);
            this.label7.TabIndex = 32;
            this.label7.Text = "Tên Group";
            // 
            // huyquyeng
            // 
            this.huyquyeng.Location = new System.Drawing.Point(231, 208);
            this.huyquyeng.Name = "huyquyeng";
            this.huyquyeng.Size = new System.Drawing.Size(177, 23);
            this.huyquyeng.TabIndex = 31;
            this.huyquyeng.Text = "Hủy quyền Group";
            this.huyquyeng.UseVisualStyleBackColor = true;
            this.huyquyeng.Click += new System.EventHandler(this.huyquyeng_Click_1);
            // 
            // csua
            // 
            this.csua.AutoSize = true;
            this.csua.Location = new System.Drawing.Point(84, 177);
            this.csua.Name = "csua";
            this.csua.Size = new System.Drawing.Size(44, 19);
            this.csua.TabIndex = 30;
            this.csua.Text = "Sửa";
            this.csua.UseVisualStyleBackColor = true;
            this.csua.CheckedChanged += new System.EventHandler(this.csua_CheckedChanged);
            // 
            // cthem
            // 
            this.cthem.AutoSize = true;
            this.cthem.Location = new System.Drawing.Point(84, 151);
            this.cthem.Name = "cthem";
            this.cthem.Size = new System.Drawing.Size(54, 19);
            this.cthem.TabIndex = 29;
            this.cthem.Text = "Thêm";
            this.cthem.UseVisualStyleBackColor = true;
            this.cthem.CheckedChanged += new System.EventHandler(this.cthem_CheckedChanged);
            // 
            // cxoa
            // 
            this.cxoa.AutoSize = true;
            this.cxoa.Location = new System.Drawing.Point(231, 151);
            this.cxoa.Name = "cxoa";
            this.cxoa.Size = new System.Drawing.Size(46, 19);
            this.cxoa.TabIndex = 28;
            this.cxoa.Text = "Xóa";
            this.cxoa.UseVisualStyleBackColor = true;
            this.cxoa.CheckedChanged += new System.EventHandler(this.cxoa_CheckedChanged);
            // 
            // cxem
            // 
            this.cxem.AutoSize = true;
            this.cxem.Location = new System.Drawing.Point(231, 177);
            this.cxem.Name = "cxem";
            this.cxem.Size = new System.Drawing.Size(49, 19);
            this.cxem.TabIndex = 27;
            this.cxem.Text = "Xem";
            this.cxem.UseVisualStyleBackColor = true;
            // 
            // cgroup
            // 
            this.cgroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cgroup.FormattingEnabled = true;
            this.cgroup.Location = new System.Drawing.Point(84, 119);
            this.cgroup.Name = "cgroup";
            this.cgroup.Size = new System.Drawing.Size(118, 23);
            this.cgroup.TabIndex = 25;
            this.cgroup.SelectedIndexChanged += new System.EventHandler(this.cgroup_SelectedValueChanged);
            this.cgroup.Click += new System.EventHandler(this.cgroup_Click);
            // 
            // themquyeng
            // 
            this.themquyeng.Location = new System.Drawing.Point(25, 208);
            this.themquyeng.Name = "themquyeng";
            this.themquyeng.Size = new System.Drawing.Size(177, 23);
            this.themquyeng.TabIndex = 23;
            this.themquyeng.Text = "Thêm quyền vào Group";
            this.themquyeng.UseVisualStyleBackColor = true;
            this.themquyeng.Click += new System.EventHandler(this.themquyeng_Click);
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(216, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 19);
            this.label5.TabIndex = 16;
            this.label5.Text = "Đối tượng";
            // 
            // gthem
            // 
            this.gthem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.gthem.FormattingEnabled = true;
            this.gthem.Location = new System.Drawing.Point(305, 119);
            this.gthem.Name = "gthem";
            this.gthem.Size = new System.Drawing.Size(118, 23);
            this.gthem.TabIndex = 15;
            this.gthem.SelectedIndexChanged += new System.EventHandler(this.gthem_SelectedValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(2, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 15);
            this.label4.TabIndex = 13;
            this.label4.Text = "Tên Group";
            // 
            // FormPhanQuyen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(917, 543);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "FormPhanQuyen";
            this.Text = "Phân quyền người dùng";
            this.Load += new System.EventHandler(this.Ganquyen_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Button tim;
        private System.Windows.Forms.Label timuserv;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button xoausernhom;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button Taogroup;
        private System.Windows.Forms.TextBox tenuser;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button addusernhom;
        private System.Windows.Forms.ComboBox tgroup;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button huyquyeng;
        private System.Windows.Forms.CheckBox csua;
        private System.Windows.Forms.CheckBox cthem;
        private System.Windows.Forms.CheckBox cxoa;
        private System.Windows.Forms.CheckBox cxem;
        private System.Windows.Forms.ComboBox cgroup;
        private System.Windows.Forms.Button themquyeng;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox gthem;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox listug;
        private System.Windows.Forms.ComboBox listuser;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox timgroup;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button taouser;
        private System.Windows.Forms.TextBox tengroup;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.TextBox pass;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}